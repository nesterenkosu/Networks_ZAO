<?php
	if(isset($_GET["mysid"]))
		session_id($_GET["mysid"]);
	
	session_start();
	
	if(!isset($_GET["mysid"]))
		die(session_id());
	
	if(isset($_GET["v"]))
		$_SESSION[1]=$_GET["v"];

	echo "Значение сессии =".$_SESSION[1]."<br/>";