<?php
if(isset($_GET["mysession_id"]))
	session_id($_GET["mysession_id"]);
/*else {
	session_start();
	die(session_id());
}*/

if(file_exists("sessionid.txt")) {
	//Если глобальная сессия уже создана
	$sid=file_get_contents("sessionid.txt");//получение id сессии из файла
	session_id($sid); //подключение к сессии с заданным id
	session_start(); //начало работы с сессией
	
	$_SESSION["hello"]="hello";
	//echo "Получена существущая сессия";
}else {
	//Если глобальная сессия ещё не создана
	session_start(); //запуск новой сессии
	$sid=session_id(); //получение её id
	file_put_contents("sessionid.txt",$sid); //сохранение полученного id в файл
	
	//Инициализация переменных сессии
	$_SESSION["session_client0"]=""; //Сессия первого клиента
	$_SESSION["session_client1"]=""; //Сессия второго клиента
	$_SESSION["session_server0"]=""; //Сессия сервера для приятия данных от первого клиента
	$_SESSION["session_server1"]=""; //Сессия сервера для приятия данных от второго клиента
	
	//echo "Создана новая сессия";
	
	//pre_r($_SESSION);
}

$actor=isset($_GET["server"])?"server":"client";

if(isset($_GET["program_id"])) {
	$program_id=(int)$_GET["program_id"];
	if(isset($_GET["send"])) {
		//echo "Значение присвоено session_id=[$sid]";
	$_SESSION["session_{$actor}{$program_id}"]=file_get_contents("php://input");//$_GET["v"];
		//pre_r($_SESSION);
		session_write_close();
		
	}else if(isset($_GET["receive"])) {
		/*echo "Значение принято session_id=[$sid]";
		pre_r($_SESSION);
		echo "v=".$_SESSION["prog$program_id"];*/
		echo $_SESSION["session_{$actor}{$program_id}"];
		$_SESSION["session_{$actor}{$program_id}"]="";
		
	}
	
	exit(0);
}

//echo "<br/>";

echo $sid;
//pre_r($_SESSION);


function pre_r($arr) {
	echo "<pre>";print_r($arr);echo "</pre>";
}

/*echo "id сессии =".session_id()."<br/>";

//$_SESSION[user_id]

if(isset($_GET["v"]))
	$_SESSION["server"]=$_GET["v"];

echo "Значение сессии =".$_SESSION["server"]."<br/>";*/
