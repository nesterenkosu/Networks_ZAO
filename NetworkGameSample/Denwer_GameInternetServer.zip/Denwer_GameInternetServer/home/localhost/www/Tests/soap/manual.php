﻿<?php
$answer="";
//Если была нажата кнопка "Отправить"
if(isset($_POST["req_go"]))
{
	$request_server=trim($_POST["req_server"]);
	$request_port=(int)$_POST["req_port"];
	$request_url=trim($_POST["req_url"]);
	$request_xml=stripslashes(trim($_POST["req_xml"]));
	$sock = fsockopen($request_server, $request_port, $errno, $errstr, 30);
	if(!$sock) 
		$answer="Ошибка создания сокета: \nerrno=$errno\n errstr=$errstr\n";
	else
		{
			fwrite($sock, "POST $request_url HTTP/1.0\r\n");
			fwrite($sock, "User-Agent: PHPRPC/1.0\r\n");
			fwrite($sock, "Host: $request_server\r\n");			
			fwrite($sock, "Content-type: text/xml\r\n");
			fwrite($sock, "Content-length: " . strlen($request_xml) . "\r\n");
			//fwrite($sock, 'SOAPAction: "http://tempuri.org/IlabSOAP/MyFirstProc"\r\n');			
			fwrite($sock, "Accept: */*\r\n");			
			fwrite($sock, "\r\n");
			fwrite($sock, "$request_xml\r\n");
			fwrite($sock, "\r\n");
			
			//Получение заголовков ответа
			$headers = "";
			while ($str = trim(fgets($sock, 4096))) {
				$headers .= "$str\n";
			}
			
			//Получение тела ответа (XML-данные)
			$data = "";
			while (!feof($sock)) {
				$data .= fgets($sock, 4096);
			}
			
			$answer="<textarea style=\"width:50%;height: 90%;\" disabled=\"disabled\">$headers\n\n$data</textarea>";
		}
}
?>
<form action="" method="POST">	
	Хост:<input name="req_server" type="text" size="10" value="<?=$request_server?>"/>
	Порт:<input name="req_port" type="text" size="5" value="<?=$request_port?>"/>
	Путь к сервису:<input name="req_url" type="text" size="60" value="<?=$request_url?>"/><br/>
	<textarea style="width: 50%; height: 90%" name="req_xml"><?=$request_xml?></textarea><?=$answer?><br/>
	<input name="req_go" type="submit" value="Отправить"/><br/>
</form>