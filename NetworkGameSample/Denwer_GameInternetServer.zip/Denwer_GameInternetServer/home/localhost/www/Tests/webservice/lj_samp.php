﻿<?
	require_once("XML/RPC.php");
	
	$client = new XML_RPC_Client('/interface/xmlrpc', 'www.livejournal.com',80 /*,'192.168.99.225',8080*/);
	
	$mystruct = Array(
		"username"=>new XML_RPC_Value("inf_study","string"),
		"password"=>new XML_RPC_Value("do520xLpim4","string"),
		"event"=>new XML_RPC_Value("Text of the message.Текст объявления","string"),
		//"event"=>new XML_RPC_Value("Первая запись из API на русском!","string"),
		"lineendings"=>new XML_RPC_Value(0x0A,"int"),
		//"subject"=>new XML_RPC_Value("А как у нас с великим и могучим?","string"),
		"subject"=>new XML_RPC_Value("Debugging 22.12","string"),
		"year"=>new XML_RPC_Value(2015,"int"),
		"mon"=>new XML_RPC_Value(10,"int"),
		"day"=>new XML_RPC_Value(29,"int"),
		"hour"=>new XML_RPC_Value(19,"int"),
		"min"=>new XML_RPC_Value(30,"int"),
	); 
	
	$params = Array(
		new XML_RPC_Value($mystruct,"struct")	
	);
	
	$msg = new XML_RPC_Message("LJ.XMLRPC.postevent",$params);
	echo "<xmp>";
	$client->setDebug(1);
	
	$ret=$client->send($msg);
	echo "</xmp>";
	$val=$ret->value();
	
	echo "<hr/>ret";
	echo "<pre>";
	var_dump($ret);
	echo "</pre>";
	
	echo "<hr/>faultString";
	echo "[".$ret->faultString()."]<br/>";
	echo "<hr/>scalarval";
	echo "[[[".$val->scalarval()."]]]";
	
?>